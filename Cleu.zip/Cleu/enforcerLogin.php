<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>

    <style>
        .loginContainer{
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        body{
            background: url('./img/catbalogan.jpg');
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
        }
    </style>

<body>

    <div class='loginContainer'>
        <div class="card" style="width: 40rem;">
            <h2 class="card-header text-center">Traffic Violators Management System</h2>
            <div class="card-body">
                <div class="p-3">
                    <div class="text-center">
                        <h1 class="h1 text-gray-900 mb-2">LOGIN</h1>
                        <p class="mb-4">Welcome Officer!</p>
                    </div>
                    <form class="user" action="code.php" method="POST">
                        <div class="form-group">
                            <input type="password" name="passcode" class="mt-3 form-control form-control-user"
                                id="exampleInputEmail" aria-describedby="emailHelp"
                                placeholder="Enter Passcode">
                        </div>
                        <div class="text-center mt-3">
                            <input type="submit" name="btn_passcode" class="btn btn-primary btn-user btn-block"/>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>