
<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
        $row = mysqli_fetch_object($chck_user);
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>

    <body id="page-top">

        <!-- Page Wrapper -->
        <div id="wrapper">

            <?php include 'inc/sidebar.php'; ?>

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <?php include 'inc/topbar.php'; ?>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <?php
                                date_default_timezone_set('Asia/Manila');
                                $date = date('M d, Y', time());
                            ?>
                            <h1 class="h3 mb-0 text-gray-800">Welcome Admin</h1>
                            <h1 class="h3 mb-0 text-gray-800"><?php echo $date; ?></h1>
                        </div>

                        <div class="row">

                            <div class="col-xl-12 col-lg-7">
                                <div class="card shadow mb-4">
                                    <!-- Card Header - Dropdown -->
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">User List</h6>

                                        <input type="button" class="btn btn-secondary btn-user" data-bs-toggle="modal" data-bs-target="#regModal" value="+ Add User"/>
                                    </div>
                                    
                                    <!-- Card Body -->
                                    <div class="card-body table-responsive">
                                    
                                    <?php
                                        $result=$conn->query("SELECT * FROM tbl_user WHERE user_type = '2' AND acc_status = '1' ");

                                        if(mysqli_num_rows($result)>0){
                                            echo "<table id='tbl_patientList' class='table table-striped' style='width:100%'>";
                                            echo "<thead>";	
                                            echo "<tr>";	
                                                
                                                echo "<th><b> Name </b></th>";
                                                echo "<th><b> Driver Type </th></b>";
                                                echo "<th><b> Date </th></b>";
                                                echo "<th><b> Action </th></b>";

                                            echo "</tr>";
                                            echo "</thead>";
                                            echo "<tbody>";

                                        while($row=mysqli_fetch_object($result)){

                                            echo "<tr>";
                                            
                                                echo "<td>$row->f_name $row->m_name $row->l_name</td>";
                                                echo "<td>$row->driverType</td>";
                                                echo "<td>$row->date_submit</td>";

                                                echo "<form method='GET' action='code.php'>";
                                                    echo "<input type='hidden' name='userID' value='$row->user_id'>";
                                                    
                                                    echo "<td><input type='submit' id='btn_viewUser' name='btn_viewUser' class='btn btn-success col-md-12' value='View'></td>";
                                                echo "</form>";
                                        ?>	
                                                
                                        <?php
                                            
                                        }
                                            echo "</tr>";	
                                            echo "</tbody>";
                                        echo "</table>";
                                        }else{
                                            echo "<br><h3 class='card-title' style='text-align:center;'> NO RECORD YET ! </h3>";
                                        }
                                    ?> 

                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>


        </div>

        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <?php include 'inc/bootstrap.php'; ?>




        

        <!-- Modal Registration -->
        <div class="modal fade" id="regModal" tabindex="-1" aria-labelledby="regModal" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">

                    <form method="POST" action="code.php" enctype="multipart/form-data">
                        <div class="modal-body">
                            <h2 class="text-center p-3">Register Here</h2>
                            <div class="row">
                                <div class="col-6">
                                    <input type="text" class="form-control" placeholder="First name" aria-label="First name" name="f_name" required>
                                </div>
                                <div class="col-6 mb-3">
                                    <input type="text" class="form-control" placeholder="Middle name" aria-label="Last name" name="m_name" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <input type="text" class="form-control" placeholder="Last name" aria-label="First name" name="l_name" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <select class="form-control" name="address" aria-label="Default select example">
                                        <option selected hidden>Address</option>
                                        <option>Albalate, Catbalogan Samar</option>
                                        <option>Bagongon, Catbalogan Samar</option>
                                        <option>Bangon, Catbalogan Samar</option>
                                        <option>Basiao, Catbalogan Samar</option>
                                        <option>Buluan, Catbalogan Samar</option>
                                        <option>Bunuanan, Catbalogan Samar</option>
                                        <option>Cabugawan, Catbalogan Samar</option>
                                        <option>Cagudalo, Catbalogan Samar</option>
                                        <option>Cagusipan, Catbalogan Samar</option>
                                        <option>Cagutian, Catbalogan Samar</option>
                                        <option>Cagutsan, Catbalogan Samar</option>
                                        <option>Canhawan Guti, Catbalogan Samar</option>
                                        <option>Canlapwas (Poblacion 15), Catbalogan Samar</option>
                                        <option>Cawayan, Catbalogan Samar</option>
                                        <option>Cinco, Catbalogan Samar</option>
                                        <option>Darahuway Daco, Catbalogan Samar</option>
                                        <option>Darahuway Guti, Catbalogan Samar</option>
                                        <option>Estaka, Catbalogan Samar</option>
                                        <option>Guindapunan, Catbalogan Samar</option>
                                        <option>Ibol, Catbalogan Samar</option>
                                        <option>Iguid, Catbalogan Samar</option>
                                        <option>Lagundi, Catbalogan Samar</option>
                                        <option>Libas, Catbalogan Samar</option>
                                        <option>Lobo, Catbalogan Samar</option>
                                        <option>Manguehay, Catbalogan Samar</option>
                                        <option>Maulong (Oraa), Catbalogan Samar</option>
                                        <option>Mercedes, Catbalogan Samar</option>
                                        <option>Mombon, Catbalogan Samar</option>
                                        <option>New Mahayag (Anayan), Catbalogan Samar</option>
                                        <option>Palanyogon, Catbalogan Samar</option>
                                        <option>Pangdan, Catbalogan Samar</option>
                                        <option>Payao, Catbalogan Samar</option>
                                        <option>Poblacion 1 (Barangay 1), Catbalogan Samar</option>
                                        <option>Poblacion 2 (Barangay 2), Catbalogan Samar</option>
                                        <option>Poblacion 3 (Barangay 3), Catbalogan Samar</option>
                                        <option>Poblacion 4 (Barangay 4), Catbalogan Samar</option>
                                        <option>Poblacion 5 (Barangay 5), Catbalogan Samar</option>
                                        <option>Poblacion 6 (Barangay 6), Catbalogan Samar</option>
                                        <option>Poblacion 7 (Barangay 7), Catbalogan Samar</option>
                                        <option>Poblacion 8 (Barangay 8), Catbalogan Samar</option>
                                        <option>Poblacion 9 (Barangay 9), Catbalogan Samar</option>
                                        <option>Poblacion 10 (Barangay 10), Catbalogan Samar</option>
                                        <option>Poblacion 11 (Barangay 11), Catbalogan Samar</option>
                                        <option>Poblacion 12 (Barangay 12), Catbalogan Samar</option>
                                        <option>Poblacion 13 (Barangay 13), Catbalogan Samar</option>
                                        <option>Muñoz (Poblacion 14), Catbalogan Samar</option>
                                        <option>Rama, Catbalogan Samar</option>
                                        <option>San Andres, Catbalogan Samar</option>
                                        <option>San Pablo, Catbalogan Samar</option>
                                        <option>San Roque, Catbalogan Samar</option>
                                        <option>San Vicente, Catbalogan Samar</option>
                                        <option>Silanga (Papaya), Catbalogan Samar</option>
                                        <option>Socorro, Catbalogan Samar</option>
                                        <option>Totoringon, Catbalogan Samar</option>
                                    </select>
                                </div>

                                <div class="col-12 mb-3">
                                    <select class="form-control" name="driverType" aria-label="Default select example">
                                        <option selected hidden>Driver Type</option>
                                        <option>Tricycle Driver</option>
                                        <option>Motorcycle Driver</option>
                                        <option>4 Wheels Driver</option>
                                    </select>
                                </div>
                                
                                <!-- <div class="col-md-12 mb-3 border-bottom-secondary"></div>
                                <h3 class='text-center col-md-12'>Driver License</h3>
                                <div class="col-md-6 mb-3">
                                    <input type="file" class="form-control" name="file1" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <input type="file" class="form-control" name="file2" required>
                                </div>
                                <div class="col-md-12 mb-3 border-bottom-secondary"></div> -->


                                <div class="col-12 mb-3">
                                    <input type="text" class="form-control" placeholder="Username" aria-label="First name" name="user_name" required>
                                </div>
                                <div class="col-12 mb-3">
                                    <input type="password" class="form-control" placeholder="Password" aria-label="First name" name="password" required>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <input type="submit" class="btn btn-primary" value="Submit" name="btn_signUp"/>
                        </div>
                    </form>

                </div>
            </div>
        </div>
        <!-- Modal Registration -->	







        <!-- VIEW MODAL -->
            <?php
                if (isset($_SESSION['toViewID']) && $_SESSION['toViewID'] != '') {
                    $user_id = $_SESSION['toViewID'];
                    $sqlUser = $conn->query("SELECT * from tbl_credentials WHERE user_id = '$user_id' ");
                    
            ?>
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                        <div class="modal-body p-5">
                            <?php   
                                if(mysqli_num_rows($sqlUser) >= 1){
                                    $result = mysqli_fetch_object($sqlUser);
                            ?>
                                <div class="input-group mb-3">
                                    <span class="input-group-text bg-white col-4 mr-2" id="basic-addon1">Plate Number</span>
                                    <input type="text" class="form-control bg-white col-8" value="<?php echo $result->plateNumber; ?>" aria-label="Username" aria-describedby="basic-addon1">
                                </div>

                                <div class="input-group mb-3">
                                    <span class="input-group-text bg-white col-4" id="basic-addon1">Driver's license</span>
                                    <img class='col-4 bg-white' alt='front-picture' src="uploads/<?php echo $result->driverLicense_front; ?>">
                                    <img class='col-4 bg-white' alt='front-picture' src="uploads/<?php echo $result->driverLicense_back; ?>">
                                </div>

                                <div class="input-group mb-3">
                                    <span class="input-group-text bg-white col-4" id="basic-addon1">Official Receipt</span>
                                    <img class='col-8 bg-white' alt='front-picture' src="uploads/<?php echo $result->official_r; ?>">
                                </div>

                                <div class="input-group mb-3">
                                    <span class="input-group-text bg-white col-4" id="basic-addon1">Certificate Of Registration</span>
                                    <img class='col-8 bg-white' alt='front-picture' src="uploads/<?php echo $result->cr; ?>">
                                </div>
                            <?php }else { ?>

                                <h2 class='text-center text-danger mb-0 pb-0'>No Credentials Yet !</h2>

                            <?php } ?>
                        </div>
                        </div>
                    </div>
                </div>
            <?php
                } unset($_SESSION['toViewID']);
            ?>						
        <!-- VIEW MODAL -->

        <script>
            $(document).ready(function () {
                $('#tbl_patientList').DataTable();
            });

            $('#exampleModal').modal("show");
                $('#cancel').click(function() {
                    $('#exampleModal').modal("hide");
            });
        </script>

    </body>

</html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>