
<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_enforcer WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
        $row = mysqli_fetch_object($chck_user);
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>

  
    <body id="page-top">

        <!-- Page Wrapper -->
        <div id="wrapper">

            <?php include 'inc/enforcerSidebar.php'; ?>

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <?php include 'inc/topbarEnforcer.php'; ?>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <?php
                                date_default_timezone_set('Asia/Manila');
                                $date = date('M d, Y', time());
                            ?>
                            <h1 class="h3 mb-0 text-gray-800">Welcome Admin</h1>
                            <h1 class="h3 mb-0 text-gray-800"><?php echo $date; ?></h1>
                        </div>

                        <div class="row">

                            <div class="col-xl-4 col-md-6 mb-4">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <?php 
                                                    $query_sec= $conn->query("SELECT * FROM tbl_user ");
                                                    $ttlUser = mysqli_fetch_object($query_sec);
                                                ?>
                                                <div class="text-lg font-weight-bold text-primary text-uppercase mb-4">
                                                    Create Violation
                                                </div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    
                                                    <form action='code.php' method='POST'>
                                                        <div class="input-group mb-3">
                                                            <input type="text" required name='plateSearch' class="form-control" placeholder="Enter Plate Number" aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                            <button name='btnSearch' type='submit' class='btn btn-sm btn-info col-4'>Search</button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-8 col-md-6 mb-4">
                                <div class="card border-left-success shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2 table-responsive">
                                                <?php 
                                                    $query_sec= $conn->query("SELECT COUNT(*)as totalAd FROM tbl_user WHERE user_type = '1' ");
                                                    $ttlAdmin = mysqli_fetch_object($query_sec);
                                                    $admin = $ttlAdmin->totalAd;
                                                ?>
                                                <div class="h5 mb-0 text-gray-800">
                                                <?php
                                                    $name = $_SESSION['user_fname'];
                                                    $result=$conn->query("SELECT * FROM tbl_violators WHERE enforcerName = '$name' ");

                                                    if(mysqli_num_rows($result)>0){
                                                        echo "<table id='tbl_patientList' class='table table-striped' style='width:100%'>";
                                                        echo "<thead>";	
                                                        echo "<tr>";	
                                                            
                                                            echo "<th><b> Name </b></th>";
                                                            echo "<th><b> Picture </b></th>";
                                                            echo "<th><b> Violation</th></b>";
                                                            echo "<th><b> Fee </th></b>";

                                                        echo "</tr>";
                                                        echo "</thead>";
                                                        echo "<tbody>";

                                                    while($row=mysqli_fetch_object($result)){

                                                        echo "<tr>";
                                                        
                                                            echo "<td>$row->name</td>";
                                                            echo "<td>
                                                                <img src='./img/$row->pic' class='img-fluid' alt='Violation Picture' width='200'>
                                                            </td>";
                                                            echo "<td>$row->violation</td>";
                                                            echo "<td>₱ $row->fee</td>";
                                                    ?>	
                                                            
                                                    <?php
                                                        
                                                    }
                                                        echo "</tr>";	
                                                        echo "</tbody>";
                                                    echo "</table>";
                                                    }else{
                                                        echo "<br><h3 class='card-title' style='text-align:center;'> NO RECORD YET ! </h3>";
                                                    }
                                                ?> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>


        </div>

        <?php include 'inc/bootstrap.php'; ?>


        <?php
            if (isset($_SESSION['plateSearch']) && $_SESSION['plateSearch'] != '') {
                $plateSearch = $_SESSION['plateSearch'];
                $sqlPlate = $conn->query("SELECT * FROM tbl_credentials WHERE plateNumber = '$plateSearch' ");
                if(mysqli_num_rows($sqlPlate) >= 1){
                    $rowCre = mysqli_fetch_object($sqlPlate);
        ?>
                    <div class="modal fade" id="plateSearch" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                            <?php 
                                $uID = $rowCre->user_id;
                                $sqlUser = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$uID' ");
                                $rowUser = mysqli_fetch_object($sqlUser);
                            ?>
                            <form class='p-3 pt-0' action="code.php" method='POST' enctype="multipart/form-data">
                                <h3 class="text-center text-success fw-boldest" id="exampleModalLabel">Plate # : <?php echo $plateSearch; ?></h3>
                                <div class="modal-body">
                                    <div class='row mb-3'>
                                        <input type="text" class='bg-white form-control col-4' readonly value='Name'>
                                        <input type="text" class='bg-white form-control col-8' name='name' readonly value='<?php echo $rowUser->f_name.' '.$rowUser->m_name.' '.$rowUser->l_name ?>'>
                                    </div>
                                    <div class='row mb-3'>
                                        <input type="text" class='bg-white form-control col-4' readonly value='Picture'>
                                        <input type="file" class='bg-white form-control col-8' name='pic' required>
                                    </div>
                                    <div class='row mb-3'>
                                        <input type="text" class='bg-white form-control col-4' readonly value='Violation'>
                                        <select class="form-select col-8" aria-label="Default select example" name='violation' required>
                                            <option selected value='' hidden>Select Violation</option>
                                            <option value="Driving Without a Valid License">Driving Without a Valid License</option>
                                            <option value="Reckless Driving">Reckless Driving</option>
                                            <option value="Driving Under the Influence of Alcohol and/or Prohibited Drugs">Driving Under the Influence of Alcohol and/or Prohibited Drugs</option>
                                            <option value="Obstruction Violation">Obstruction Violation</option>
                                            <option value="Number Coding or Color Coding Scheme">Number Coding or Color Coding Scheme</option>
                                            <option value="Illegal Parking">Illegal Parking</option>
                                            <option value="Loading and Unloading in Prohibited Areas">Loading and Unloading in Prohibited Areas</option>
                                            <option value="Truck Ban">Truck Ban</option>
                                            <option value="Motorcycle Lane Policy">Motorcycle Lane Policy</option>
                                            <option value="Illegal Counterflow">Illegal Counterflow</option>
                                        </select>
                                    </div>
                                    <div class='row mb-3'>
                                        <input type="text" class='bg-white form-control col-4' readonly value='Vehicle Type' >
                                        <select class="form-select col-8" aria-label="Default select example" name='vehType' required>
                                            <option selected value='' hidden>Select Vehicle Type</option>
                                            <option value="Truck">Truck</option>
                                            <option value="Bus">Bus</option>
                                            <option value="Motorcycle">Motorcycle</option>
                                            <option value="Tricycle">Tricycle</option>
                                        </select>
                                    </div>
                                    <div class="row">
                                        <textarea required class="form-control" name='desc' placeholder="Description" id="floatingTextarea2" style="height: 100px"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="hidden" value='<?php echo $_SESSION['user_fname']; ?>' name='enforcer'>
                                    <input type="hidden" value='<?php echo $plateSearch; ?>' name='plateNumber'>

                                    <!-- <button type="button" id="cancel" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                                    <button type="submit" name='btnSubVio' class="btn btn-primary">Submit</button>
                                </div>
                                </div>
                            </form>

                        </div>
                    </div>
        <?php
                }else{
        ?>
                    <div class="modal fade" id="plateSearch" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-body">
                                <h2 class='text-center text-danger'>"<?php echo $plateSearch; ?>" DID'NT EXIST !</h2>
                            </div>
                            </div>
                        </div>
                    </div>
        <?php
                }
            } unset($_SESSION['plateSearch']);
        ?>	

        <script>
            $(document).ready(function () {
                $('#tbl_patientList').DataTable();
            });

            $('#plateSearch').modal("show");
                $('#cancel').click(function() {
                    $('#plateSearch').modal("hide");
            });
        </script>
    </body>


</html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>