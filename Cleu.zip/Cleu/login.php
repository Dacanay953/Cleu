<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>

    <style>
        .loginContainer{
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        body{
            background: url('./img/catbalogan.jpg');
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
        }
    </style>

<body>

    <div class='loginContainer'>
        <div class="card" style="width: 40rem;">
            <h2 class="card-header text-center">Traffic Violation Management System</h2>
            <div class="card-body">
                <div class="p-3">
                    <div class="text-center">
                        <h1 class="h1 text-gray-900 mb-2">LOGIN</h1>
                        <p class="mb-4">Welcome Back!</p>
                    </div>
                    <form class="user" action="code.php" method="POST">
                        <div class="form-group">
                            <input type="text" name="user_name" class="form-control form-control-user"
                                id="exampleInputEmail" aria-describedby="emailHelp"
                                placeholder="Username">

                            <input type="password" name="user_pass" class="mt-3 form-control form-control-user"
                                id="exampleInputEmail" aria-describedby="emailHelp"
                                placeholder="Password">
                        </div>
                        <div class="text-center mt-3">
                            <input type="submit" name="btn_logIn" class="btn btn-primary btn-user btn-block"/>
                        </div>
                        <!-- <div class="text-center mt-3">
                            <input type="button" class="btn btn-secondary btn-user btn-block" data-bs-toggle="modal" data-bs-target="#exampleModal" value="Register"/>
                        </div> -->
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Registration -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModal" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-dialog-centered">
			<div class="modal-content">

    			<form method="POST" action="code.php" enctype="multipart/form-data">
    				<div class="modal-body">
    					<h2 class="text-center p-3">Register Here</h2>
						<div class="row">
							<div class="col-6">
								<input type="text" class="form-control" placeholder="First name" aria-label="First name" name="f_name" required>
							</div>
							<div class="col-6 mb-3">
								<input type="text" class="form-control" placeholder="Middle name" aria-label="Last name" name="m_name" required>
							</div>
							<div class="col-12 mb-3">
								<input type="text" class="form-control" placeholder="Last name" aria-label="First name" name="l_name" required>
							</div>
                            <div class="col-12 mb-3">
                                <select class="form-control" name="address" aria-label="Default select example">
                                    <option selected hidden>Address</option>
                                    <option>Albalate, Catbalogan Samar</option>
                                    <option>Bagongon, Catbalogan Samar</option>
                                    <option>Bangon, Catbalogan Samar</option>
                                    <option>Basiao, Catbalogan Samar</option>
                                    <option>Buluan, Catbalogan Samar</option>
                                    <option>Bunuanan, Catbalogan Samar</option>
                                    <option>Cabugawan, Catbalogan Samar</option>
                                    <option>Cagudalo, Catbalogan Samar</option>
                                    <option>Cagusipan, Catbalogan Samar</option>
                                    <option>Cagutian, Catbalogan Samar</option>
                                    <option>Cagutsan, Catbalogan Samar</option>
                                    <option>Canhawan Guti, Catbalogan Samar</option>
                                    <option>Canlapwas (Poblacion 15), Catbalogan Samar</option>
                                    <option>Cawayan, Catbalogan Samar</option>
                                    <option>Cinco, Catbalogan Samar</option>
                                    <option>Darahuway Daco, Catbalogan Samar</option>
                                    <option>Darahuway Guti, Catbalogan Samar</option>
                                    <option>Estaka, Catbalogan Samar</option>
                                    <option>Guindapunan, Catbalogan Samar</option>
                                    <option>Ibol, Catbalogan Samar</option>
                                    <option>Iguid, Catbalogan Samar</option>
                                    <option>Lagundi, Catbalogan Samar</option>
                                    <option>Libas, Catbalogan Samar</option>
                                    <option>Lobo, Catbalogan Samar</option>
                                    <option>Manguehay, Catbalogan Samar</option>
                                    <option>Maulong (Oraa), Catbalogan Samar</option>
                                    <option>Mercedes, Catbalogan Samar</option>
                                    <option>Mombon, Catbalogan Samar</option>
                                    <option>New Mahayag (Anayan), Catbalogan Samar</option>
                                    <option>Palanyogon, Catbalogan Samar</option>
                                    <option>Pangdan, Catbalogan Samar</option>
                                    <option>Payao, Catbalogan Samar</option>
                                    <option>Poblacion 1 (Barangay 1), Catbalogan Samar</option>
                                    <option>Poblacion 2 (Barangay 2), Catbalogan Samar</option>
                                    <option>Poblacion 3 (Barangay 3), Catbalogan Samar</option>
                                    <option>Poblacion 4 (Barangay 4), Catbalogan Samar</option>
                                    <option>Poblacion 5 (Barangay 5), Catbalogan Samar</option>
                                    <option>Poblacion 6 (Barangay 6), Catbalogan Samar</option>
                                    <option>Poblacion 7 (Barangay 7), Catbalogan Samar</option>
                                    <option>Poblacion 8 (Barangay 8), Catbalogan Samar</option>
                                    <option>Poblacion 9 (Barangay 9), Catbalogan Samar</option>
                                    <option>Poblacion 10 (Barangay 10), Catbalogan Samar</option>
                                    <option>Poblacion 11 (Barangay 11), Catbalogan Samar</option>
                                    <option>Poblacion 12 (Barangay 12), Catbalogan Samar</option>
                                    <option>Poblacion 13 (Barangay 13), Catbalogan Samar</option>
                                    <option>Muñoz (Poblacion 14), Catbalogan Samar</option>
                                    <option>Rama, Catbalogan Samar</option>
                                    <option>San Andres, Catbalogan Samar</option>
                                    <option>San Pablo, Catbalogan Samar</option>
                                    <option>San Roque, Catbalogan Samar</option>
                                    <option>San Vicente, Catbalogan Samar</option>
                                    <option>Silanga (Papaya), Catbalogan Samar</option>
                                    <option>Socorro, Catbalogan Samar</option>
                                    <option>Totoringon, Catbalogan Samar</option>
                                </select>
                            </div>

                            <div class="col-12 mb-3">
                                <select class="form-control" name="driverType" aria-label="Default select example">
                                    <option selected hidden>Driver Type</option>
                                    <option>Tricycle Driver</option>
                                    <option>Motorcycle Driver</option>
                                    <option>4 Wheels Driver</option>
                                </select>
                            </div>
                            
                            <!-- <div class="col-md-12 mb-3 border-bottom-secondary"></div>
                            <h3 class='text-center col-md-12'>Driver License</h3>
                            <div class="col-md-6 mb-3">
                                <input type="file" class="form-control" name="file1" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <input type="file" class="form-control" name="file2" required>
                            </div>
                            <div class="col-md-12 mb-3 border-bottom-secondary"></div> -->


							<div class="col-12 mb-3">
								<input type="text" class="form-control" placeholder="Username" aria-label="First name" name="user_name" required>
							</div>
							<div class="col-12 mb-3">
								<input type="password" class="form-control" placeholder="Password" aria-label="First name" name="password" required>
							</div>
						</div>
    				</div>
    				<div class="modal-footer">
    					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    					<input type="submit" class="btn btn-primary" value="Submit" name="btn_signUp"/>
    				</div>
    			</form>

			</div>
		</div>
	</div>
	<!-- Modal Registration -->	






    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>