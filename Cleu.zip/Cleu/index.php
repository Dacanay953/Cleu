
<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
        $row = mysqli_fetch_object($chck_user);
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>

    <?php 
    if($row->user_type === '1'){
    ?>
        <body id="page-top">

            <!-- Page Wrapper -->
            <div id="wrapper">

                <?php include 'inc/sidebar.php'; ?>

                <!-- Content Wrapper -->
                <div id="content-wrapper" class="d-flex flex-column">

                    <!-- Main Content -->
                    <div id="content">

                        <?php include 'inc/topbar.php'; ?>

                        <div class="container-fluid">

                            <!-- Page Heading -->
                            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                                <?php
                                    date_default_timezone_set('Asia/Manila');
                                    $date = date('M d, Y', time());
                                ?>
                                <h1 class="h3 mb-0 text-gray-800">Welcome Admin</h1>
                                <h1 class="h3 mb-0 text-gray-800"><?php echo $date; ?></h1>
                            </div>

                            <div class="row">

                                <div class="col-xl-6 col-md-6 mb-4">
                                    <div class="card border-left-primary shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <?php 
                                                        $query_sec= $conn->query("SELECT COUNT(*)as totaluser FROM tbl_user WHERE user_type = '2' AND acc_status = '1'  ");
                                                        $ttlUser = mysqli_fetch_object($query_sec);
                                                        $user = $ttlUser->totaluser;
                                                    ?>
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        Total User
                                                    </div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $user; ?></div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-users fa-2x text-gray-300"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xl-6 col-md-6 mb-4">
                                    <div class="card border-left-success shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <?php 
                                                        $query_sec= $conn->query("SELECT COUNT(*)as totalAd FROM tbl_user WHERE user_type = '1' ");
                                                        $ttlAdmin = mysqli_fetch_object($query_sec);
                                                        $admin = $ttlAdmin->totalAd;
                                                    ?>
                                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                        Total Admin
                                                    </div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $admin; ?></div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-book fa-2x text-gray-300"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>


            </div>

            <?php include 'inc/bootstrap.php'; ?>

        </body>
    <?php 
    }elseif($row->user_type === '2'){
    ?>

        <body id="page-top">

            <!-- Page Wrapper -->
            <div id="wrapper">

                <?php include 'inc/sidebar.php'; ?>

                <!-- Content Wrapper -->
                <div id="content-wrapper" class="d-flex flex-column">

                    <!-- Main Content -->
                    <div id="content">

                        <?php include 'inc/topbar.php'; ?>

                        <?php 
                            $sqlDriver = $conn->query("SELECT * FROM tbl_credentials WHERE user_id = '$userID' ");
                            if(mysqli_num_rows($sqlDriver) == 0){   
                        ?>

                            <div class="col-xl-12 col-lg-7">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">Driver and Vehicle's Information</h6>
                                    </div>
                                    
                                    <div class="card-body">
                                        <?php 
                                            $driverType = $_SESSION['driverType'];
                                            if($driverType === 'Motorcycle Driver' || $driverType === '4 Wheels Driver'){
                                        ?>

                                            <form action="code.php" method='POST' enctype="multipart/form-data">
                                                <div class="row modal-body">
                                                    <div class="col-md-12 mb-3">
                                                        <input type="text" placeholder='Plate Number' class="form-control" name="plateNumber" required>
                                                    </div>
                                                    <h3 class='text-center col-md-12 mb-3 '>Drivers License</h3>
                                                    <div class="col-md-4 mb-3">
                                                        <input type="text" readonly class="form-control bg-white" value="Front Picture">
                                                    </div>
                                                    <div class="col-md-8 mb-3">
                                                        <input type="file" class="form-control" name="file1" required>
                                                    </div>

                                                    <div class="col-md-4 mb-3">
                                                        <input type="text" class="form-control" value="Back Picture">
                                                    </div>
                                                    <div class="col-md-8 mb-3">
                                                        <input type="file" class="form-control" name="file2" required>
                                                    </div>

                                                    <h3 class='text-center col-md-12 mb-3 '>Certificate of Registration (CR)</h3>
                                                    <div class="col-md-12 mb-3">
                                                        <input type="file" class="form-control" name="file3" required>
                                                    </div>

                                                    <h3 class='text-center col-md-12 mb-3 '>Official Receipt (OR)</h3>
                                                    <div class="col-md-12 mb-3">
                                                        <input type="file" class="form-control" name="file4" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name='btnSubmitCre' class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>

                                        <?php }else if($driverType === 'Tricycle Driver') { ?>

                                            <form action="code.php" method='POST' enctype="multipart/form-data">
                                                <div class="row modal-body">
                                                    <h3 class='text-center col-md-12 mb-3 '>Plate Number Registration</h3>

                                                    <div class="col-md-12 mb-3">
                                                        <input type="text" placeholder='Plate Number' class="form-control" name="plateNumber" required>
                                                    </div>

                                                    <div class="col-md-4 mb-3">
                                                        <input type="text" readonly class="form-control bg-white" value="Front Picture">
                                                    </div>
                                                    <div class="col-md-8 mb-3">
                                                        <input type="file" class="form-control" name="file1" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name='btnSubmitCre' class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>

                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                            

                        <?php }else { ?>

                            <div class="container-fluid">

                                <!-- Page Heading -->
                                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                                    <?php
                                        date_default_timezone_set('Asia/Manila');
                                        $date = date('M d, Y', time());
                                    ?>
                                    <h1 class="h3 mb-0 text-gray-800">Welcome User</h1>
                                    <h1 class="h3 mb-0 text-gray-800"><?php echo $date; ?></h1>
                                </div>

                                <div class="row">

                                    <div class="col-xl-6 col-lg-7">
                                        <div class="card shadow mb-4">
                                            <!-- Card Header - Dropdown -->
                                            <?php  
                                                $address = $_SESSION['add'];
                                                $address = str_replace(" ", "+", $address);
                                            ?>
                                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                                <h6 class="m-0 font-weight-bold text-primary">Catbalogan City Traffic Route Map Data as of <?php echo $date; ?></h6>
                                            </div>
                                            
                                            <!-- Card Body -->
                                            <div class="card-body">
                                            <!-- <div id="map"></div> -->

                                            <script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>
                                            <link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>
                                                    <?php
                                                        $latitude = 11.77546;
                                                        $longitude = 124.88407;
                                                    ?>

                                                    <style>
                                                        .maps{
                                                            display: flex;
                                                        }

                                                        .maps iframe{
                                                            width: 100%;
                                                            border-radius: 10px;
                                                        }

                                                        .maps iframe:first-child{
                                                            margin-right: 10px;
                                                        }
                                                    </style>

                                                    <div class="maps">
                                                        <!-- <iframe height="500" src="https://maps.google.com/maps?q=<?php echo $address; ?>&output=embed"></iframe> -->
                                                        <iframe height="500" src="https://api.mapbox.com/styles/v1/examples/ck7pbezoo07661ioxtn6qsmuw.html?access_token=pk.eyJ1IjoiZXhhbXBsZXMiLCJhIjoiY2p0MG01MXRqMW45cjQzb2R6b2ptc3J4MSJ9.zA2W0IkI0c6KaAhJfk9bWg#14.62/11.77909/124.88305"></iframe> 
                                                    </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-7">
                                        <div class="card shadow mb-4">
                                            <?php  
                                                $address = $_SESSION['add'];
                                                $address = str_replace(" ", "+", $address);
                                            ?>
                                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                                <h6 class="m-0 font-weight-bold text-primary">Traffic Violations History</h6>
                                            </div>
                                            
                                            <div class="card-body">
                                                <?php
                                                    $name = $_SESSION['user_fname'];
                                                    $result=$conn->query("SELECT * FROM tbl_violators WHERE name = '$name' ");

                                                    if(mysqli_num_rows($result)>0){
                                                        echo "<table id='tbl_patientList' class='table table-striped' style='width:100%'>";
                                                        echo "<thead>";	
                                                        echo "<tr>";	
                                                            
                                                            echo "<th><b> Violation ID </b></th>";
                                                            echo "<th><b> Violation</th></b>";
                                                            echo "<th><b> Fee </th></b>";

                                                        echo "</tr>";
                                                        echo "</thead>";
                                                        echo "<tbody>";

                                                    while($row=mysqli_fetch_object($result)){

                                                        echo "<tr>";
                                                        
                                                            echo "<td>$row->vioID</td>";
                                                            echo "<td>$row->violation</td>";
                                                            echo "<td>₱ $row->fee</td>";
                                                    ?>	
                                                            
                                                    <?php
                                                        
                                                    }
                                                        echo "</tr>";	
                                                        echo "</tbody>";
                                                    echo "</table>";
                                                    }else{
                                                        echo "<br><h3 class='card-title' style='text-align:center;'> NO RECORD YET ! </h3>";
                                                    }
                                                ?> 
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        <?php } ?>

                    </div>

                </div>


            </div>

            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>

            <?php include 'inc/bootstrap.php'; ?>

            <script>
                $(document).ready(function () {
                    $('#tbl_patientList').DataTable();
                });

                $('#staticBackdrop').modal("show");
                    $('#cancel').click(function() {
                        $('#staticBackdrop').modal("hide");
                });
            </script>

        </body>

    <?php } ?>

</html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>