-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2024 at 05:13 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `traffic`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_credentials`
--

CREATE TABLE `tbl_credentials` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `driverLicense_front` varchar(255) NOT NULL,
  `driverLicense_back` varchar(255) NOT NULL,
  `official_r` varchar(255) NOT NULL,
  `cr` varchar(255) NOT NULL,
  `plateNumber` varchar(255) NOT NULL,
  `plateNumber_pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_credentials`
--

INSERT INTO `tbl_credentials` (`id`, `user_id`, `driverLicense_front`, `driverLicense_back`, `official_r`, `cr`, `plateNumber`, `plateNumber_pic`) VALUES
(8, 240554, 'AA.png', 'clark-tibbs-oqStl2L5oxI-unsplash.jpg', 'AA.png', 'sideviewPic.png', 'Ph-101', 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enforcer`
--

CREATE TABLE `tbl_enforcer` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_enforcer`
--

INSERT INTO `tbl_enforcer` (`id`, `user_id`, `f_name`, `m_name`, `l_name`) VALUES
(4, '773502', 'Jerson', 'Versoza', 'Nieva');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `payBy` varchar(255) NOT NULL,
  `vioID` varchar(255) NOT NULL,
  `payment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`id`, `transaction_id`, `payBy`, `vioID`, `payment`) VALUES
(6, '572883', 'Juan D, Dela Cruz', '879422', '150'),
(7, '441426', 'Juan D, Dela Cruz', '437323', '2000 ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_treasurer`
--

CREATE TABLE `tbl_treasurer` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_treasurer`
--

INSERT INTO `tbl_treasurer` (`id`, `user_id`, `f_name`, `m_name`, `l_name`, `username`, `password`) VALUES
(1, '459157', 'Joyce', 'Gelilang', 'Sapetin', 'joyce', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `driverType` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_submit` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `acc_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user_id`, `f_name`, `m_name`, `l_name`, `address`, `driverType`, `user_name`, `password`, `date_submit`, `user_type`, `acc_status`) VALUES
(4, '365977', 'Emman', 'D.', 'Calem', 'Cagudalo, Catbalogan Samar', '4 Wheels Driver', 'Admin', '$2y$10$TEK8WPsZDNoGLJygQ.yH4eet0v3RwxBvsnnXCS8e2ZoSRYZvRDVkS', 'Dec 12, 2023', '1', '1'),
(9, '240554', 'Juan', 'D,', 'Dela Cruz', 'Cagusipan, Catbalogan Samar', 'Motorcycle Driver', 'juan', '$2y$10$NNUVn2cykefAKonO14BGl.z/n8WkXNsLhPreSSgTqn2jViCSHrByS', 'Jan 08, 2024', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_violation`
--

CREATE TABLE `tbl_violation` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fee` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_violation`
--

INSERT INTO `tbl_violation` (`id`, `name`, `fee`) VALUES
(1, 'Driving Without a Valid License', '3000'),
(2, 'Reckless Driving', '2000'),
(3, 'Driving Under the Influence of Alcohol and/or Prohibited Drugs', '50000'),
(4, 'Obstruction Violation', '150'),
(5, 'Number Coding or Color Coding Scheme', '300'),
(6, 'Illegal Parking', '200 '),
(7, 'Loading and Unloading in Prohibited Areas', '150'),
(8, 'Truck Ban', '2000'),
(9, 'Motorcycle Lane Policy', '500 '),
(10, 'Illegal Counterflow', '2000 ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_violators`
--

CREATE TABLE `tbl_violators` (
  `id` int(255) NOT NULL,
  `vioID` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `violation` varchar(255) NOT NULL,
  `fee` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `enforcerName` varchar(255) NOT NULL,
  `vehicleType` varchar(255) NOT NULL,
  `plateNumber` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_violators`
--

INSERT INTO `tbl_violators` (`id`, `vioID`, `name`, `violation`, `fee`, `date`, `enforcerName`, `vehicleType`, `plateNumber`, `description`) VALUES
(7, '879422', 'Juan D, Dela Cruz', 'Loading and Unloading in Prohibited Areas', '0', 'Jan 08, 2024', 'Jerson Versoza Nieva', 'Motorcycle', 'Ph-101', 'Sample Desc'),
(8, '437323', 'Juan D, Dela Cruz', 'Illegal Counterflow', '0', 'Jan 08, 2024', 'Jerson Versoza Nieva', 'Motorcycle', 'Ph-101', 'NONE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_credentials`
--
ALTER TABLE `tbl_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_enforcer`
--
ALTER TABLE `tbl_enforcer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_treasurer`
--
ALTER TABLE `tbl_treasurer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_violation`
--
ALTER TABLE `tbl_violation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_violators`
--
ALTER TABLE `tbl_violators`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_credentials`
--
ALTER TABLE `tbl_credentials`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_enforcer`
--
ALTER TABLE `tbl_enforcer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_treasurer`
--
ALTER TABLE `tbl_treasurer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_violation`
--
ALTER TABLE `tbl_violation`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_violators`
--
ALTER TABLE `tbl_violators`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
