
<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_treasurer WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
        $row = mysqli_fetch_object($chck_user);
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>

    <body id="page-top">

        <!-- Page Wrapper -->
        <div id="wrapper">

            <?php include 'inc/treaSidebar.php'; ?>

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <?php include 'inc/topbar.php'; ?>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <?php
                                date_default_timezone_set('Asia/Manila');
                                $date = date('M d, Y', time());
                            ?>
                            <h1 class="h3 mb-0 text-gray-800">Welcome Treasurer</h1>
                            <h1 class="h3 mb-0 text-gray-800"><?php echo $date; ?></h1>
                        </div>

                        <div class="row">

                            <div class="col-xl-12 col-lg-7">
                                <div class="card shadow mb-4 table-responsive">
                                    <!-- Card Header - Dropdown -->
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">Violators List</h6>
                                        <button type="button" class="btn btn-primary" id="printButton">+ Create Report</button>
                                    </div>
                                    
                                    <!-- Card Body -->
                                    <div class="card-body table-responsive">

                                    <?php 
                                        $sql = "SELECT * FROM tbl_violators";
                                        $result = mysqli_query($conn, $sql);
                                    ?>
                                    <table id='printRequest' class='table table-hover col-md-12' style='width:100%'>
                                        <thead>
                                            <th class='text-center' colspan='10'>
                                                <div class="d-flex justify-content-around align-items-center">
                                                    <img src="img/cleu.png" class="img-fluid" alt="Cleu Logo" style="width: 170px; height: 100px;">
                                                    <h4>
                                                        CATBALOGAN CITY TRAFFIC OFFENSES AND VIOLATION RECORDS MANAGEMENT SYSTEM 
                                                    </h4>
                                                </div>
                                            </th>
                                            <tr>
                                                <td><b>Name</b></td>
                                                <td><b>Picture</b></td>
                                                <td><b>Violation</b></td>
                                                <td><b>Fee</b></td>
                                                <td><b>Date</b></td>
                                                <td><b>Enforcer</b></td>
                                                <td><b>Plate no.</b></td>
                                                <td><b>Vehicle Type</b></td>
                                                <td><b>Status</b></td>
                                                <td><b>Action</b></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            while($row = mysqli_fetch_array($result)) { 
                                        ?>
                                            <tr>
                                                <td><?php echo $row['name']; ?></td>
                                                <td>
                                                    <img src='./img/<?php echo $row['pic']; ?>' class='img-fluid' alt='Violation Picture' width='150'>
                                                </td>
                                                <td><?php echo $row['violation']; ?></td>
                                                <td><?php echo $row['fee']; ?></td>
                                                <td><?php echo $row['date']; ?></td>
                                                <td><?php echo $row['enforcerName']; ?></td>
                                                <td><?php echo $row['plateNumber']; ?></td>
                                                <td><?php echo $row['vehicleType']; ?></td>

                                                <form action="code.php" method="POST">
                                                    <input type='hidden' name='vioID' value='<?php echo $row['vioID']; ?>' />
                                                    <?php 
                                                        if($row['fee'] === '0'){
                                                    ?>
                                                            <td><p>PAID</p></td>
                                                            <td><p>PAID</p></td>
                                                    <?php
                                                        }else{
                                                            echo "<td><p>PENDING</p></td>";
                                                            echo "<td><input type='submit' id='btnPay' name='btnPay' class='btn btn-success col-md-12' value='Pay'></td>";
                                                        }
                                                    ?>
                                                </form>
                                                
                                            </tr>
                                        <?php } ?>
                                        
                                        </tbody>
                                    </table>

                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>


        </div>

        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <?php include 'inc/bootstrap.php'; ?>



        <!-- VIEW MODAL -->
            <?php
                if (isset($_SESSION['vioID']) && $_SESSION['vioID'] != '') {
                    $vioID = $_SESSION['vioID'];
                    $sqlVio = $conn->query("SELECT * from tbl_violators WHERE vioID = '$vioID' ");
                    $result = mysqli_fetch_object($sqlVio);
            ?>

                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Violation ID : <?php echo $vioID; ?></h5>
                            </div>
                            <form action="code.php" method='POST'>
                                <div class="modal-body">
                                    <div class='row mb-3'>
                                        <input type="text" class='bg-white form-control col-4' readonly value='Violation'>
                                        <input type="text" class='bg-white form-control col-8' name='violation' readonly value='<?php echo $result->violation; ?>'>
                                    </div>
                                    <div class='row mb-3'>
                                        <input type="text" class='bg-white form-control col-4' readonly value='Fee'>
                                        <input type="text" class='bg-white form-control col-8' name='fee' readonly value='<?php echo $result->fee; ?>'>
                                    </div>
                                    <div class='row mb-3'>
                                        <input type="text" class='bg-white form-control col-4' readonly value='Payment'>
                                        <input type="text" required class='bg-white form-control col-8' name='payment' placeholder='Payment'>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="hidden" name='name' value='<?php echo $result->name; ?>'>
                                    <input type="hidden" name='vioID' value='<?php echo $vioID; ?>'>

                                    <button type="submit" name='btnSubmit_pay' class="btn btn-primary">Submit</button>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>

            <?php
                } unset($_SESSION['vioID']);
            ?>						
        <!-- VIEW MODAL -->


        <script>
            function print() {
            printJS({
                printable: 'printRequest',
                type: 'html',
                targetStyles: ['*']
            })
            }

            document.getElementById('printButton').addEventListener("click", print)
        
            <?php include 'toPrintArea.js'; ?>

        </script>


        <script>
            $(document).ready(function () {
                $('#printRequest').DataTable();
            });

            $('#exampleModal').modal("show");
                $('#cancel').click(function() {
                    $('#exampleModal').modal("hide");
            });
        </script>

    </body>

</html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>