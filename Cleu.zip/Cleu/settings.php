<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
        $row = mysqli_fetch_object($chck_user);
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php' ?>


<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <?php include 'inc/sidebar.php' ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <?php include 'inc/topbar.php' ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4" >
                    <h1 class="h3 mb-0 text-gray-800">Settings</h1>
                </div>

                <div class="row">

                    <div class="col-xl-6 col-md-6 mb-4" > 
                        <div class="card shadow h-100 py-2" style="background: #FAF9F6;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xl font-weight-bold text-primary text-uppercase mb-1">
                                            Update Name
                                        </div>
                                        <div class="row h5 mb-0 font-weight-bold text-gray-800">
                                            <?php
						                    	$userID = $_SESSION['user_id'];
												$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
						                        $user = mysqli_fetch_object($chck_user);
						                    ?>
                                            <form action="code.php" method='GET' class='row col-md-12'>
                                                <div class="col-4 mb-3">
                                                    <input type="text" readonly class="form-control bg-white" value="Firstname" aria-label="Last name" name="" required>
                                                </div>
                                                <div class="col-8">
                                                    <input type="text" class="form-control bg-white" minlength="3" pattern="[^()/><\][\\\x22,;|]+" value="<?php echo $user->f_name ; ?>" aria-label="First name" name="f_name" required>
                                                </div>

                                                <div class="col-4 mb-3">
                                                    <input type="text" readonly class="form-control bg-white" value="Lastname" aria-label="Last name" name="" required>
                                                </div>
                                                <div class="col-8">
                                                    <input type="text" class="form-control bg-white" minlength="3" pattern="[^()/><\][\\\x22,;|]+" value="<?php echo $user->l_name ; ?>" aria-label="First name" name="l_name" required>
                                                </div>
                                                <div class="col-12">
                                                    <input type="hidden" value="<?php echo $row->user_id; ?>" name="user_id" />
                                                    
                                                    <input type="submit" value="Update" name='btn_updateUser' class='btn btn-info col-md-12'>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-6 col-md-6 mb-4" > 
                        <div class="card shadow h-100 py-2" style="background: #FAF9F6;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xl font-weight-bold text-primary text-uppercase mb-1">
                                            Update Password
                                        </div>
                                        <div class="row h5 mb-0 font-weight-bold text-gray-800">
                                            <?php 
                                                $id = $_SESSION['user_id'];
                                                $select_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$id'  ");
                                                $row = mysqli_fetch_object($select_user);
                                            ?>
                                            <form action="code.php" method='GET' class='row col-md-12'>
                                                <div class="col-4 mb-3">
                                                    <input type="text" readonly class="form-control bg-white" value="Current Password" aria-label="Last name" name="" required >
                                                </div>
                                                <div class="col-8">
                                                    <input type="password" class="form-control bg-white" minlength="3" pattern="[^()/><\][\\\x22,;|]+" aria-label="First name" name="curr_pass" required>
                                                </div>

                                                <div class="col-4 mb-3">
                                                    <input type="text" readonly class="form-control bg-white" value="New Password" aria-label="Last name" name="" required>
                                                </div>
                                                <div class="col-8">
                                                    <input type="password" class="form-control bg-white" minlength="3" pattern="[^()/><\][\\\x22,;|]+" aria-label="First name" required name="new_pass">
                                                </div>

                                                <div class="col-4 mb-3">
                                                    <input type="text" readonly class="form-control bg-white" value="Confirm Password" aria-label="Last name" name="" required>
                                                </div>
                                                <div class="col-8">
                                                    <input type="password" class="form-control bg-white" minlength="3" pattern="[^()/><\][\\\x22,;|]+" aria-label="First name" name="confirm_pass" required>
                                                </div>
                                                <div class="col-12">
                                                    <input type="hidden" value="<?php echo $row->user_id; ?>" name="user_id" />
                                                    
                                                    <input type="submit" value="Update" name='btn_updatePass' class='btn btn-info col-md-12'>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

				</div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>

</body>


<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>