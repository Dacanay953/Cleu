
<?php 
    session_start();
    include 'connection.php';

		// Login
		if(isset($_POST['btn_logIn'])){
			$username = $_POST['user_name'];
			$password = $_POST['user_pass'];

				//read from database
				$query_admin = "SELECT * FROM tbl_user WHERE user_name = '$username' ";
				$result_admin = mysqli_query($conn, $query_admin);

				if(mysqli_num_rows($result_admin) > 0){
					$user_data = mysqli_fetch_assoc($result_admin);
					
					// ADMIN TEACHER
					$password_dec = $user_data['password'];

					$veryfy = password_verify($password, $password_dec);

					if($veryfy){
						// Admin Database
						$_SESSION['user_id'] = $user_data['user_id'];
						$_SESSION['acc_status'] = $user_data['acc_status'];
						$_SESSION['add'] = $user_data['address'];
						$_SESSION['driverType'] = $user_data['driverType'];
							
						$_SESSION['user_fname'] = $user_data['f_name'] ." ". $user_data['m_name'] ." ". $user_data['l_name'];

						$login_success = "Message          :        Welcome  " . $_SESSION['user_fname'];
						?>
							<script>
								alert('<?php echo $login_success; ?>');
								window.location.href="index.php";
							</script>  
						<?php
						
					}else{
						$login_error = "Username or Password Incorrect!";
						?>
							<script>
								alert('<?php echo $login_error; ?>');
								window.location.href="login.php";
							</script>                
						<?php

					}
						
				}else if(mysqli_num_rows($result_admin) < 1){

					$username = $_POST['user_name'];
					$password = $_POST['user_pass'];

					$query_trea = "SELECT * FROM tbl_treasurer WHERE username = '$username' AND password = '$password' ";
					$result_trea = mysqli_query($conn, $query_trea);

					if(mysqli_num_rows($result_trea) > 0){
						$user_data = mysqli_fetch_assoc($result_trea);
						
						$password_dec = $user_data['password'];
	
						$_SESSION['user_id'] = $user_data['user_id'];
						$_SESSION['username'] = $user_data['username'];
						$_SESSION['password'] = $user_data['password'];
							
						$_SESSION['user_fname'] = $user_data['f_name'] ." ". $user_data['m_name'] ." ". $user_data['l_name'];

						$login_success = "Message          :        Welcome  " . $_SESSION['user_fname'];
						?>
							<script>
								alert('<?php echo $login_success; ?>');
								window.location.href="indexTreasurer.php";
							</script>  
						<?php


					}else{
						$login_error = "Username or Password Incorrect!";
						?>
							<script>
								alert('<?php echo $login_error; ?>');
								window.location.href="login.php";
							</script>                
						<?php

					}

				}else{
					$login_error = "Username or Password Incorrect!";
					?>
						<script>
							alert('<?php echo $login_error; ?>');
							window.location.href="login.php";
						</script>                
					<?php

				}
		}
		// Login


		// REG USER
		if(isset($_POST['btn_signUp'])){
			// $filename = $_FILES['file1']['name'];
			// $filename2 = $_FILES['file2']['name'];
			$f_name = $_POST['f_name'];
			$l_name = $_POST['l_name'];
			$m_name = $_POST['m_name'];
			$username = $_POST['user_name'];
			$password = $_POST['password'];
			$address = $_POST['address'];
			$driverType = $_POST['driverType'];

			// $expireNum = $_POST['expireNum'];
			// $licenseNum = $_POST['licenseNum'];
			// $serialNum = $_POST['serialNum'];

			$query_user = $conn->query("SELECT * FROM tbl_user WHERE f_name = '$f_name' AND l_name = '$l_name'");
			$query_row = mysqli_num_rows($query_user);

			if($query_row >= 1){

				$acc_err = "Message                :        Account already exist !";
					?>
						<script>
							alert('<?php echo $acc_err; ?>');
							window.location.href="userList.php";
						</script>  
					<?php 

			}elseif($query_row <= 1){
				$created = @date('M d, Y');
				$user_id = $user_id = rand(100000,999999);
				$hash_password = password_hash($password, PASSWORD_DEFAULT);

				$sql = "INSERT INTO tbl_user
								(user_id, f_name, m_name, l_name, address, driverType, user_name, password, date_submit, 
								user_type, acc_status) 
								VALUES
								( '$user_id', '$f_name', '$m_name', '$l_name', '$address', '$driverType', '$username', '$hash_password', '$created', 
								'2', '1')";
				mysqli_query($conn, $sql);

				?>
					<script>
						alert('<?php echo "Account Created !"; ?>');
						window.location.href="userList.php"; 
					</script>                
				<?php

				// if($filename != '' && $filename2 != ''){
				// 	$ext = pathinfo($filename, PATHINFO_EXTENSION);
				// 	$allowed = ['jpeg', 'png', 'jpg'];
				
				// 	//check if file type is valid
				// 	if (in_array($ext, $allowed)){
				// 		$path = 'uploads/';
							
				// 		$created = @date('M d, Y');
				// 		move_uploaded_file($_FILES['file1']['tmp_name'],($path . $filename));
				// 		move_uploaded_file($_FILES['file2']['tmp_name'],($path . $filename2));
		
				// 		$user_id = $user_id = rand(100000,999999);
				// 		$hash_password = password_hash($password, PASSWORD_DEFAULT);
						
				// 		// insert file details into database
				// 		$sql = "INSERT INTO tbl_user
				// 				(user_id, f_name, m_name, l_name, address, drivers_license, drivers_licenseback, user_name, password, date_submit, 
				// 				user_type, acc_status, expiration_date, license_no, serial_no) 
				// 				VALUES
				// 				( '$user_id', '$f_name', '$m_name', '$l_name', '$address', '$filename', '$filename2', '$username', '$hash_password', '$created', 
				// 				'2', 0, '$expireNum', '$licenseNum', '$serialNum')";
				// 		mysqli_query($conn, $sql);

				// 		?>
				// 			<script>
				// 				alert('<?php echo "Account is on review !"; ?>');
				// 				window.location.href="login.php"; 
				// 			</script>                
				// 		<?php

				// 	}else{
				// 		?>
				// 			<script>
				// 				alert('<?php echo "Account error !"; ?>');
				// 				window.location.href="login.php"; 
				// 			</script>                
				// 		<?php
				// 	}
				// }

			}
		}
		// REG USER


		// APPROVE USER
		if(isset($_GET['btn_approve'])){
			$userID = $_GET['userID'];

			$query_user = $conn->query("UPDATE tbl_user SET acc_status = '1' WHERE user_id = '$userID' ");

			$acc_err = "Message                :        Account approved !";
			?>
				<script>
					alert('<?php echo $acc_err; ?>');
					window.location.href="approve.php";
				</script>  
			<?php 
			
		}
		// APPROVE USER


		// DECLINE USER
		if(isset($_GET['btn_decline'])){
			$userID = $_GET['userID'];

			$query_user = $conn->query("UPDATE tbl_user SET acc_status = '2' WHERE user_id = '$userID' ");

			$acc_err = "Message                :        Account declined !";
			?>
				<script>
					alert('<?php echo $acc_err; ?>');
					window.location.href="approve.php";
				</script>  
			<?php 
			
		} 
		// DECLINE USER


		// VIEW USER
		if(isset($_GET['btn_view'])){
			echo $_SESSION['toViewID'] = $_GET['userID'];
			header("location:approve.php" );
		} 
		// VIEW USER


		// VIEW USER
		if(isset($_GET['btn_viewUser'])){
			echo $_SESSION['toViewID'] = $_GET['userID'];
			header("location:userlist.php" );
		} 
		// VIEW USER



		// Credentials
		if(isset($_POST['btnSubmitCre'])){
			$user_id = $_SESSION['user_id'];
			$driverType = $_SESSION['driverType'];
			$plateNumber = $_POST['plateNumber'];

			if($driverType === 'Tricycle Driver'){

				$filename = $_FILES['file1']['name'];
	
				if($filename != ''){
					$ext = pathinfo($filename, PATHINFO_EXTENSION);
					$allowed = ['jpeg', 'png', 'jpg'];
				
					//check if file type is valid
					if (in_array($ext, $allowed)){
						$path = 'uploads/';
							
						$created = @date('M d, Y');
						move_uploaded_file($_FILES['file1']['tmp_name'],($path . $filename));

						// insert file details into database
						$sql = "INSERT INTO tbl_credentials
								(user_id, driverLicense_front, driverLicense_back, official_r, cr, plateNumber, plateNumber_pic) 
								VALUES
								( '$user_id', 'N/A', 'N/A','N/A','N/A','$plateNumber', '$filename' )";
						mysqli_query($conn, $sql);
	
						?>
							<script>
								alert('<?php echo "Credentials Submitted !"; ?>');
								window.location.href="index.php"; 
							</script>                
						<?php
	
					}else{
						?>
							<script>
								alert('<?php echo "Submit error !"; ?>');
								window.location.href="index.php"; 
							</script>                
						<?php
					}
				}

			}else if($driverType === 'Motorcycle Driver' || $driverType === '4 Wheels Driver'){

				$filename = $_FILES['file1']['name'];
				$filename2 = $_FILES['file2']['name'];
				$filename3 = $_FILES['file3']['name'];
				$filename4 = $_FILES['file4']['name'];

				if($filename != '' && $filename2 != '' && $filename3 != '' && $filename4 != ''){
					$ext = pathinfo($filename, PATHINFO_EXTENSION);
					$allowed = ['jpeg', 'png', 'jpg'];
				
					//check if file type is valid
					if (in_array($ext, $allowed)){
						$path = 'uploads/';
							
						$created = @date('M d, Y');
						move_uploaded_file($_FILES['file1']['tmp_name'],($path . $filename));
						move_uploaded_file($_FILES['file2']['tmp_name'],($path . $filename2));
						move_uploaded_file($_FILES['file3']['tmp_name'],($path . $filename3));
						move_uploaded_file($_FILES['file4']['tmp_name'],($path . $filename4));

						// insert file details into database
						$sql = "INSERT INTO tbl_credentials
								(user_id, driverLicense_front, driverLicense_back, official_r, cr, plateNumber, plateNumber_pic) 
								VALUES
								( '$user_id', '$filename', '$filename2','$filename3','$filename4','$plateNumber', 'N/A' )";
						mysqli_query($conn, $sql);
	
						?>
							<script>
								alert('<?php echo "Credentials Submitted !"; ?>');
								window.location.href="index.php"; 
							</script>                
						<?php
	
					}else{
						?>
							<script>
								alert('<?php echo "Submit error !"; ?>');
								window.location.href="index.php"; 
							</script>                
						<?php
					}
				}

			}
		} 
		// Credentials



		// REG USER
		if(isset($_POST['btnAddEnforcer'])){
			$f_name = $_POST['f_name'];
			$l_name = $_POST['l_name'];
			$m_name = $_POST['m_name'];

			$query_user = $conn->query("SELECT * FROM tbl_enforcer WHERE f_name = '$f_name' AND l_name = '$l_name'");
			$query_row = mysqli_num_rows($query_user);

			if($query_row >= 1){

				$acc_err = "Message                :        Enforcer already exist !";
					?>
						<script>
							alert('<?php echo $acc_err; ?>');
							window.location.href="approve.php";
						</script>  
					<?php 

			}elseif($query_row <= 1){
				$user_id = $user_id = rand(100000,999999);

				$sql = "INSERT INTO tbl_enforcer
								(user_id, f_name, m_name, l_name) 
								VALUES
								( '$user_id', '$f_name', '$m_name', '$l_name')";
				mysqli_query($conn, $sql);

				?>
					<script>
						alert('<?php echo "Enforcer Added !"; ?>');
						window.location.href="approve.php"; 
					</script>                
				<?php

			}
		}
		// REG USER



		// Login Enforcer
		if(isset($_POST['btn_passcode'])){
			$passcode = $_POST['passcode'];

				//read from database
				$query_admin = "SELECT * FROM tbl_enforcer WHERE user_id = '$passcode' ";
				$result_admin = mysqli_query($conn, $query_admin);

				if(mysqli_num_rows($result_admin) > 0){
					$user_data = mysqli_fetch_assoc($result_admin);
					
					// ADMIN TEACHER
					$password_dec = $user_data['password'];

					// Admin Database
					$_SESSION['user_id'] = $user_data['user_id'];
					
					$_SESSION['user_fname'] = $user_data['f_name'] ." ". $user_data['m_name'] ." ". $user_data['l_name'];

					$login_success = "Message          :        Welcome  " . $_SESSION['user_fname'];
					?>
						<script>
							alert('<?php echo $login_success; ?>');
							window.location.href="indexEnforcer.php";
						</script>  
					<?php

						
				}else{
					$login_error = "Passcode Incorrect!";
					?>
						<script>
							alert('<?php echo $login_error; ?>');
							window.location.href="enforcerLogin.php";
						</script>                
					<?php

				}
		}
		// Login Enforcer



		// Credentials
		if(isset($_POST['btnSearch'])){
			$_SESSION['plateSearch'] = $_POST['plateSearch'];

			?>
				<script>
					window.location.href="indexEnforcer.php"; 
				</script>                
			<?php
		} 
		// Credentials


		// REG USER
		if(isset($_POST['btnSubVio'])){
			$name = $_POST['name'];
			$violation = $_POST['violation'];
			$vehType = $_POST['vehType'];
			$enforcer = $_POST['enforcer'];
			$plateNumber = $_POST['plateNumber'];
			$desc = $_POST['desc'];

			date_default_timezone_set('Asia/Manila');
			$created = date('M d, Y');

			$sqlViolators = $conn->query("SELECT * FROM tbl_violators WHERE name = '$name' and date = '$created' and violation = '$violation' ");

			if(mysqli_num_rows($sqlViolators) >= 1){
				?>
					<script>
						alert('Already Added!');
						window.location.href = "indexEnforcer.php";
					</script>
				<?php
			}else if(mysqli_num_rows($sqlViolators) < 1){

				$sqlFee = $conn->query("SELECT * FROM tbl_violation WHERE name = '$violation' ");
				$rowVio = mysqli_fetch_object($sqlFee);
				$fee = $rowVio->fee;

				$pic = $_FILES['pic']['name'];

				if($pic != ''){
					$ext_1 = pathinfo($pic, PATHINFO_EXTENSION);
					$allowed = ['jpeg', 'png', 'jpg'];

					//check if file type is valid
					if (in_array($ext_1, $allowed)) {
						$path = 'img/';

						$user_id = random_int(100000, 999999);

						move_uploaded_file($_FILES['pic']['tmp_name'], ($path . $pic));
		
						$sqlVio = $conn->query("INSERT INTO `tbl_violators`
															(`vioID`, `name`, `pic`, `violation`, `fee`, `date`, `enforcerName`, `vehicleType`, `plateNumber`, `description`) 
															VALUES 
															('$user_id','$name','$pic','$violation','$fee','$created','$enforcer','$vehType','$plateNumber','$desc')");

						?>
							<script>
								alert('<?php echo "Violation Added !"; ?>');
								window.location.href = "indexEnforcer.php"; 
							</script>
						<?php			

					} else {
						?>
							<script>
								alert('<?php echo "Picture error !"; ?>');
								window.location.href = "indexEnforcer.php"; 
							</script>
						<?php
					}

				}else{
					?>
						<script>
							alert('<?php echo "Adding error !"; ?>');
							window.location.href = "indexEnforcer.php"; 
						</script>
					<?php
				}


			}
			
		}
		// REG USER


		// REG USER
		if(isset($_POST['btnPay'])){
			$_SESSION['vioID'] = $vioID = $_POST['vioID'];

			?>
				<script>
					window.location.href="payment.php"; 
				</script>                
			<?php
			
		}
		// REG USER


		// REG USER
		if(isset($_POST['btnSubmit_pay'])){
			$name = $_POST['name'];
			$vioID = $_POST['vioID'];
			$payment = $_POST['payment'];
			$fee = $_POST['fee'];

			if($payment > $fee){
				?>
					<script>
						alert('Payment Eror !');
						window.location.href="payment.php"; 
					</script>                
				<?php
			}else{
				$balance = $fee - $payment;

				$transaction_id = $user_id = rand(100000,999999);

				$sqlPay = $conn->query("INSERT INTO `tbl_payment`
				(`transaction_id`, `payBy`, `vioID`, `payment`) 
				VALUES 
				('$transaction_id','$name','$vioID','$payment')");

				if($sqlPay){
					$sqlUpdate = $conn->query("UPDATE tbl_violators SET fee = '$balance' WHERE vioID = '$vioID' ");
				}

				?>
					<script>
						alert('Payment Success !');
						window.location.href="payment.php"; 
					</script>                
				<?php

			}
			
		}
		// REG USER



        // EDIT USER
		if(isset($_GET['btn_updateUser'])){         

			$uID =  $_GET['user_id'];
			$f_name =  $_GET['f_name'];
			$l_name =  $_GET['l_name'];

			$slc_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$uID' ");

			if(mysqli_num_rows($slc_user) >= 1){
				$row = mysqli_fetch_object($slc_user);
				// $u_type = $row->user_type;

				$update = $conn->query("UPDATE `tbl_user` SET 
				f_name = '$f_name', l_name = '$l_name' 
				WHERE user_id = '$uID' ");

				$msg_suc = "User              :        " . $uID .'\n'.  
				"Message       :        Successfully Updated !";

				?>
					<script>
						alert("<?php echo $msg_suc; ?>");
						window.location.href="settings.php";
					</script>  
				<?php

			}
			
		}
		// EDIT USER 


        // EDIT USER PASS
		if(isset($_GET['btn_updatePass'])){         

			$uID =  $_GET['user_id'];
			$curr_pass =  $_GET['curr_pass'];
			$new_pass =  $_GET['new_pass'];
			$confirm_pass =  $_GET['confirm_pass'];

			$slc_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$uID' ");

			if(mysqli_num_rows($slc_user) >= 1){

			$row = mysqli_fetch_object($slc_user);
			$o_pass = $row->password;

			$verifyPass = password_verify($curr_pass, $o_pass);

			if($verifyPass){

				if($new_pass == $confirm_pass){

				$hashPass = password_hash($confirm_pass, PASSWORD_DEFAULT);
				
				$update = $conn->query("UPDATE `tbl_user` SET password = '$hashPass' WHERE user_id = '$uID' ");
			
				$msg_suc = "User              :        " . $uID .'\n'.  
				"Message       :        Password Updated !";
			
				?>
					<script>
						alert("<?php echo $msg_suc; ?>");
						window.location.href="settings.php";
					</script>  
				<?php

				}else{
				$msg_err = "User              :        " . $uID .'\n'.  
				"Message       :        Password Don't Match !";
			
				?>
					<script>
						alert("<?php echo $msg_err; ?>");
						window.location.href="settings.php";
					</script>  
				<?php
				}


			}else{
				$msg_err = "User              :        " . $uID .'\n'.  
				"Message       :        Current Password Incorrect !";
			
				?>
				<script>
					alert("<?php echo $msg_err; ?>");
					window.location.href="settings.php";
				</script>  
				<?php
			}


			}
			
		}
		// EDIT USER PASS



		// REG USER
		if(isset($_POST['btnAddTrea'])){
			$f_name = $_POST['f_name'];
			$l_name = $_POST['l_name'];
			$m_name = $_POST['m_name'];
			$username = $_POST['username'];
			$password = $_POST['password'];

			$query_user = $conn->query("SELECT * FROM tbl_treasurer WHERE f_name = '$f_name' AND l_name = '$l_name' and username = '$username' ");
			$query_row = mysqli_num_rows($query_user);

			if($query_row >= 1){

				$acc_err = "Message                :        Treasurer already exist !";
					?>
						<script>
							alert('<?php echo $acc_err; ?>');
							window.location.href="treasury.php";
						</script>  
					<?php 

			}elseif($query_row <= 1){
				$user_id = $user_id = rand(100000,999999);

				$sql = "INSERT INTO tbl_treasurer
								(user_id, f_name, m_name, l_name, username, password) 
								VALUES
								( '$user_id', '$f_name', '$m_name', '$l_name','$username', '$password')";
				mysqli_query($conn, $sql);

				?>
					<script>
						alert('<?php echo "Treasurer Added !"; ?>');
						window.location.href="treasury.php"; 
					</script>                
				<?php

			}
		}
		// REG USER
?>
