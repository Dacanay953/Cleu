
<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_treasurer WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
        $row = mysqli_fetch_object($chck_user);
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>


    <body id="page-top">

        <!-- Page Wrapper -->
        <div id="wrapper">

            <?php include 'inc/treaSidebar.php'; ?>

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <?php include 'inc/topbar.php'; ?>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <?php
                                date_default_timezone_set('Asia/Manila');
                                $date = date('M d, Y', time());
                            ?>
                            <h1 class="h3 mb-0 text-gray-800">Welcome Treasurer</h1>
                            <h1 class="h3 mb-0 text-gray-800"><?php echo $date; ?></h1>
                        </div>

                        <div class="row">

                            <div class="col-xl-6 col-md-6 mb-4">
                                <div class="card border-left-success shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <?php 
                                                    $query_ttlPay = $conn->query("SELECT SUM(payment)as ttlPay FROM tbl_payment ");
                                                    $ttlPayment = mysqli_fetch_object($query_ttlPay);
                                                    $o_pay = $ttlPayment->ttlPay;
                                                ?>
                                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                    Total Payment
                                                </div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">₱ <?php echo $o_pay; ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-coins fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-6 col-md-6 mb-4">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <?php 
                                                    $query_ttlpay= $conn->query("SELECT SUM(fee)as totalPay FROM tbl_violators ");
                                                    $ttlPay = mysqli_fetch_object($query_ttlpay);
                                                    $totalPayment = $ttlPay->totalPay;
                                                ?>
                                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                    Total Pending
                                                </div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">₱ <?php echo $totalPayment; ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-coins fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>

                    </div>

                </div>

            </div>


        </div>

        <?php include 'inc/bootstrap.php'; ?>

    </body>


</html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>