
<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
        $row = mysqli_fetch_object($chck_user);
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'inc/head.php'; ?>

    <body id="page-top">

        <!-- Page Wrapper -->
        <div id="wrapper">

            <?php include 'inc/sidebar.php'; ?>

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">

                <!-- Main Content -->
                <div id="content">

                    <?php include 'inc/topbar.php'; ?>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <?php
                                date_default_timezone_set('Asia/Manila');
                                $date = date('M d, Y', time());
                            ?>
                            <h1 class="h3 mb-0 text-gray-800">Welcome Admin</h1>
                            <h1 class="h3 mb-0 text-gray-800"><?php echo $date; ?></h1>
                        </div>

                        <div class="row">

                            <div class="col-xl-12 col-lg-7">
                                <div class="card shadow mb-4">
                                    <!-- Card Header - Dropdown -->
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">Enforcer list</h6>
                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                            + Add Enforcer
                                        </button>
                                    </div>
                                    
                                    <!-- Card Body -->
                                    <div class="card-body table-responsive">
                                    
                                    <?php
                                        $result=$conn->query("SELECT * FROM tbl_enforcer  ");

                                        if(mysqli_num_rows($result)>0){
                                            echo "<table id='tbl_patientList' class='table table-striped' style='width:100%'>";
                                            echo "<thead>";	
                                            echo "<tr>";	
                                                
                                                echo "<th><b> Passcode </b></th>";
                                                echo "<th><b> Firstname </b></th>";
                                                echo "<th><b> Lastname </b></th>";
                                                echo "<th><b> Middlename </b></th>";

                                            echo "</tr>";
                                            echo "</thead>";
                                            echo "<tbody>";

                                        while($row=mysqli_fetch_object($result)){

                                            echo "<tr>";
                                            
                                                echo "<td>$row->user_id</td>";
                                                echo "<td>$row->f_name</td>";
                                                echo "<td>$row->m_name</td>";
                                                echo "<td>$row->l_name</td>";
                                        ?>	
                                                
                                        <?php
                                            
                                        }
                                            echo "</tr>";	
                                            echo "</tbody>";
                                        echo "</table>";
                                        }else{
                                            echo "<br><h3 class='card-title' style='text-align:center;'> NO RECORD YET ! </h3>";
                                        }
                                    ?> 

                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>


        </div>

        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                </div>

                <form action="code.php" method='POST'>
                    <div class="modal-body">
                        <div class="col-md-12 mb-3">
                            <input type="text" placeholder='Firstname' class="form-control" name="f_name" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input type="text" placeholder='Middlename' class="form-control" name="m_name" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input type="text" placeholder='Lastname' class="form-control" name="l_name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name='btnAddEnforcer' class="btn btn-primary">+ Add</button>
                    </div>
                </form>     

                </div>
            </div>
        </div>

        <?php include 'inc/bootstrap.php'; ?>

        <script>
            $(document).ready(function () {
                $('#tbl_patientList').DataTable();
            });
        </script>

    </body>

</html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>